This is the Monster RPG 3 Soundtrack as an NES ROM.

The music for Monster RPG 3 was made very similarly to NES music, with a
custom MML format that the game interprets for sound. There is a program
called PPMCK that creates NES music from a different MML format. For this ROM,
I converted my MML into PPMCK MML format as best I could (though some extra
features are missing.)

PPMCK ships with assembly code to create a ROM. However, it doesn't display
anything (black screen) and I wanted to have a track list. There is another
project called VegaPlay by No Carrier that is supposed to create a ROM with a
track list, but it didn't quite work for me. So I combined the code of PPMCK
and VegaPlay, with some fixes of my own, to create this ROM. That source code
can be found in ppmck.asm. You can replace the ppmck.asm in the PPMCK
distribution with this one, but you'll need a screen.nam and geo.chr file (see
VegaPlay for how to create those.) Of course, you'll also need to supply your
own MML music.

VegaPlay is GPL licensed so, this code is also GPL.
